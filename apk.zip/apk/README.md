# WhatsApp Android Edition (.apk)

Dedicated Android Mobile application package for WhatsApp Web.

## Directory Structure
- `public/`: Responsive mobile WhatsApp frontend assets (chat, profile photo upload, etc.)
- `capacitor.config.json`: Mobile configuration (app id `com.wsgoat.whatsapp`)
- `android/`: Complete native Android Studio & Gradle project
  - `app/src/main/AndroidManifest.xml`: Permissions (Internet, Camera, Storage for photo upload)
  - `app/src/main/java/com/wsgoat/whatsapp/MainActivity.java`: Native Android bridge with file chooser

## How to Build the .apk

### Option 1: Using Android Studio (Recommended)
1. Open **Android Studio**.
2. Click **Open Project** and choose the `apk/android` folder.
3. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Your `.apk` will be generated in `apk/android/app/build/outputs/apk/debug/app-debug.apk`.

### Option 2: Using Command Line
Run:
```cmd
cd apk\android
gradle assembleDebug
```
or double-click:
`apk\build-apk.bat`
